import Img from "../assets/img/logo.png";
import WhiteLogo from "../assets/img/white-logo.png";
import Managment from "../assets/img/managment.png";
import MissionImg from "../assets/img/mission.png";
import InsideImgs from "../assets/img/inside.png";
import Frame1 from "../assets/img/Frame 1.png";
import Frame2 from "../assets/img/Frame 2.png";
import Frame3 from "../assets/img/Frame 3.png";
import HeadingShadow from "../assets/img/heading.png";
import User1 from "../assets/img/user1.png";
import User2 from "../assets/img/user2.png";
import User3 from "../assets/img/user3.png";
import Userbg from "../assets/img/userbg.png";
import Backed1 from "../assets/img/backed1.png";
import Backed2 from "../assets/img/backed2.png";
import Backed3 from "../assets/img/backed3.png";
import Up from "../assets/img/upborder.png";
import Down from "../assets/img/downborder.png";
import FaqImg from "../assets/img/faq.png";
import SendButton from "../assets/img/send.png";
import InstagramIcon from "../assets/img/intsa.png";
import LinkdinIcon from "../assets/img/telegram.png";
import YoutubeIcon from "../assets/img/youtube.png";
import FacebookIcon from "../assets/img/fb.png";
import SignupImg from "../assets/img/signup.png";
import ColorGoogle from "../assets/img/google.png";
import ColorFb from "../assets/img/Facebook.png";
import ColorApple from "../assets/img/apple.png";
import SquareIcon from "../assets/img/dashboard-icons/Icon-SquaresFour.png";
import BookmarkIcon from "../assets/img/dashboard-icons/Icon-BookBookmark.png";
import BrushIcon from "../assets/img/dashboard-icons/Icon-PaintBrushHousehold.png";
import WrenchIcon from "../assets/img/dashboard-icons/Icon-Wrench.png";
import GearIcon from "../assets/img/dashboard-icons/Icon-Gear.png";
import MagnifyIcon from "../assets/img/dashboard-icons/Icon-MagnifyingGlass.png";
import WorkImg from "../assets/img/work-img.png";
import PlayIco from "../assets/img/Icon-PlayCircle.png";
import InfoIco from "../assets/img/Icon-Info.png";
import SliderImg from "../assets/img/slider.png";
import DashProfile from "../assets/img/dashprofile.png";

export {
  Img,
  WhiteLogo,
  Managment,
  MissionImg,
  InsideImgs,
  Frame1,
  Frame2,
  Frame3,
  HeadingShadow,
  User1,
  User2,
  User3,
  Userbg,
  Backed1,
  Backed2,
  Backed3,
  Up,
  Down,
  FaqImg,
  SendButton,
  InstagramIcon,
  LinkdinIcon,
  YoutubeIcon,
  FacebookIcon,
  SignupImg,
  ColorApple,
  ColorFb,
  ColorGoogle,
  SquareIcon,
  BookmarkIcon,
  BrushIcon,
  WrenchIcon,
  GearIcon,
  MagnifyIcon,
  WorkImg,
  PlayIco,
  InfoIco,
  SliderImg,
  DashProfile,
};
