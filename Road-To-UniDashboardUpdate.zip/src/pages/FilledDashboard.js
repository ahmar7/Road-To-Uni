import React from "react";
import Dashboard from "../components/FIlledDashboard/dashboard";

const FilledDashboard = () => {
  return (
    <div>
      <Dashboard />
    </div>
  );
};

export default FilledDashboard;
