import React from "react";
import NewDashboard from "../components/ZeroDashboard/zerodashboard";

const ZeroDashboard = () => {
  return (
    <div>
      <NewDashboard />
    </div>
  );
};

export default ZeroDashboard;
