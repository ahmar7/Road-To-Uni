import React from "react";
import LoginPage from "../components/Login/login";
import Footer from "../layout/Footer/Footer";
import Header from "../layout/Header/header";

const Login = () => {
  return (
    <div>
      <LoginPage />
    </div>
  );
};

export default Login;
