import React from "react";
import SignupPage from "../components/Signup/signup";
import Footer from "../layout/Footer/Footer";
import Header from "../layout/Header/header";

const Signup = () => {
  return (
    <div>
      <SignupPage />
    </div>
  );
};

export default Signup;
